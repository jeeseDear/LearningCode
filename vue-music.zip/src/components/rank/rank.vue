<template lang="">
    <div class="rank">
        排行
    </div>
</template>
<script>
    export default({

    })
</script>
