<template>
    <div class="search">
        搜索
    </div>
</template>