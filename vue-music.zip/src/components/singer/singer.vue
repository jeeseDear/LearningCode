<template>
    <div class="singer">
        歌手
    </div>
</template>